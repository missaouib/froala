package com.designre.froala.unit.entity;

import com.jparams.verifier.tostring.ToStringVerifier;
import com.designre.froala.DefaultTests;
import com.designre.froala.entity.StoredFile;
import org.junit.jupiter.api.Test;

class StoredFileTest extends DefaultTests {

	@Test
	void hasString() {
		ToStringVerifier.forClass(StoredFile.class).verify();
	}

}