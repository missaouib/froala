package com.designre.froala.unit.model;

import com.jparams.verifier.tostring.ToStringVerifier;
import com.designre.froala.DefaultTests;
import com.designre.froala.model.FileInfo;
import org.junit.jupiter.api.Test;

class FileInfoTest extends DefaultTests {

	@Test
	void hasString() {
		ToStringVerifier.forClass(FileInfo.class).verify();
	}

}